import mysql.connector
import logging

"""
This module is used to make easier queries to MySQL
The constructor takes username, password, host and a default db to perform queries on.
A different instance of the DatabaseConnector module should be created for each host you need to connect to
"""

# Setting logger for the module
logger = logging.getLogger('dbconnector')


class DatabaseConnector:
    def __init__(self, user, pwd, host, defaultdb):
        self.username = user
        self.password = pwd
        self.host = host
        self.defaultdb = defaultdb
        self.currentdb = None
        self.connection = None

    """
    This method estabilishes a connection to a certain db in the host
    If a connection is already set, it closes it, resets current db and opens a new one updating current db
    """
    def connectTo(self, database):
        if self.connection:
            logger.info('Closing pre existing connection')
            self.currentdb = None
            self.connection.close()
        try:
            self.connection = mysql.connector.connect(user=self.username, password=self.password,
                                                 host=self.host, database=database)
            self.currentdb = database
            logger.info(f'Connection to the database \'{database}\' on the host {self.host} estabilished')
        except mysql.connector.Error as e:
            raise e

    """
    This method checks whether there is a connection or not before instantiating the cursor and perform the query
    If it doesn't find any connection, it creates a new one to the default db.
    Then fetches the result and close the cursor
    """
    def query(self, query):
        if self.connection is None:
            logger.info(f'No connection, trying to connect to defaultdb on the host {self.host}')
            self.connectTo(self.defaultdb)
        cursor = self.connection.cursor()
        try:
            cursor.execute(query)
            logger.info('Query executed successfully')
            if cursor.with_rows:
                logger.debug('Query has rows')
                return cursor.fetchall()
            else:
                self.connection.commit()
            cursor.close()
        except mysql.connector.errors.Error as e:
            raise e

    """
    This method just returns the db it's using, if it's using one.
    If not, it returns nothing
    """

    def getcurrentdb(self):
        if self.connection is not None and self.currentdb is not None:
            return self.currentdb

    """
    This method just closes the connection is there's one opened.
    If not, it does nothing.
    """

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.currentdb = None
            logger.info(f'Connection to {self.host} closed')
